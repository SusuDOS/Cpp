#include<iostream>
#include<string> 
#include "workerManager.h"
using namespace std;

int main()
{
	WorkerManager wm;
	int choice = 0;
	while (1)
	{
		system("cls");
		wm.Show_Menu();
		cout << endl << "����������ѡ��:" << endl;
		cin >> choice;
		cin.get();
		switch (choice)
		{
		case 0:return 0; break;
		case 1:wm.Add_Emp(); cin.get(); break;
		case 2:wm.Show_Emp(); break; // �س�->cls->�س�->��ʾ
		case 3:wm.Del_Emp();  cin.get(); break;
		case 4:wm.Mod_Emp(); cin.get(); break;
		case 5:wm.Find_Emp();  cin.get(); break;
		case 6:wm.Sort_Emp(); cin.get(); break;
		case 7:wm.Clean_File(); cin.get(); break;
		}
	}
	return EXIT_SUCCESS;
}